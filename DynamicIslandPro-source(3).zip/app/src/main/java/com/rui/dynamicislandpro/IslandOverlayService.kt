package com.rui.dynamicislandpro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class IslandOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var island: View? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "island_service").setContentTitle("Dynamic Island Pro")
                .setContentText("動態島正在執行").setSmallIcon(android.R.drawable.ic_dialog_info).build()
        else Notification.Builder(this).setContentTitle("Dynamic Island Pro")
            .setContentText("動態島正在執行").setSmallIcon(android.R.drawable.ic_dialog_info).build()
        startForeground(7, notification)
        if (android.provider.Settings.canDrawOverlays(this)) showIsland()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("island_service", "Dynamic Island", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun showIsland() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding((18*density).toInt(), (10*density).toInt(), (18*density).toInt(), (10*density).toInt())
            setBackgroundColor(Color.BLACK)
        }
        val text = TextView(this).apply {
            this.text = "●  Dynamic Island"
            setTextColor(Color.WHITE); textSize = 12f
        }
        container.addView(text)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            (190*density).toInt(), (42*density).toInt(), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (8*density).toInt() }
        island = container
        wm.addView(container, params)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() { island?.let { if (::wm.isInitialized) wm.removeView(it) }; island = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
