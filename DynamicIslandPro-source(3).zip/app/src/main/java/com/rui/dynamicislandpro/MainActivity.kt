package com.rui.dynamicislandpro

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private val requestCode = 4102
    private val binderListener = Shizuku.OnBinderReceivedListener { refreshStatus() }
    private val deadListener = Shizuku.OnBinderDeadListener { refreshStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addBinderReceivedListener(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        render()
    }

    private lateinit var status: TextView
    private fun render() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(0xFF090A0D.toInt())
        }
        val title = TextView(this).apply {
            text = "Dynamic Island Pro"
            textSize = 26f; setTextColor(0xFFFFFFFF.toInt())
        }
        status = TextView(this).apply {
            textSize = 14f; setTextColor(0xFFB8BBC5.toInt())
            setPadding(0, pad, 0, pad)
        }
        root.addView(title)
        root.addView(status)
        root.addView(actionButton("啟用懸浮動態島") { requestOverlayAndStart() })
        root.addView(actionButton("開啟通知存取權") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        })
        root.addView(actionButton("連接 / 授權 Shizuku") { requestShizuku() })
        root.addView(actionButton("重新整理狀態") { refreshStatus() })
        setContentView(root)
        refreshStatus()
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun requestOverlayAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        } else startOverlay()
    }

    private fun startOverlay() {
        startForegroundService(Intent(this, IslandOverlayService::class.java))
    }

    private fun requestShizuku() {
        if (!Shizuku.pingBinder()) {
            status.text = "Shizuku 尚未啟動，請先開啟 Shizuku App。"
            return
        }
        if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            refreshStatus()
        } else Shizuku.requestPermission(requestCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode) refreshStatus()
    }

    private fun refreshStatus() {
        if (!::status.isInitialized) return
        val shizuku = when {
            !Shizuku.pingBinder() -> "未連線"
            Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED -> "已授權"
            else -> "已連線，未授權"
        }
        status.text = "懸浮窗：${if (Settings.canDrawOverlays(this)) "已允許" else "未允許"}\n" +
            "通知存取：${if (IslandNotificationListener.enabled(this)) "已允許" else "未允許"}\n" +
            "Shizuku：$shizuku"
    }

    override fun onResume() { super.onResume(); refreshStatus() }
    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }
}
