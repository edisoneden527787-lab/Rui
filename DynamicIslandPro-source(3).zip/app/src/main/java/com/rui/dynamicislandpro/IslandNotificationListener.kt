package com.rui.dynamicislandpro

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class IslandNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        // Notification access is real and active. A later UI iteration can render app/title/text here.
        sbn ?: return
        val title = sbn.notification.extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = sbn.notification.extras.getCharSequence("android.text")?.toString().orEmpty()
        lastNotification = listOf(title, text).filter { it.isNotBlank() }.joinToString(" · ")
    }

    companion object {
        @Volatile var lastNotification: String = ""
        fun enabled(context: Context): Boolean {
            val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
            return enabled.split(':').any { it == ComponentName(context, IslandNotificationListener::class.java).flattenToString() }
        }
    }
}
