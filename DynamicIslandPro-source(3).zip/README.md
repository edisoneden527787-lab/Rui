# Dynamic Island Pro

獨立原生 Android 專案（Kotlin）。

## 已建立的核心
- Android 懸浮窗服務（需使用者手動授予「顯示在其他應用程式上層」）。
- NotificationListenerService 通知存取權檢查與通知事件讀取。
- Shizuku API binder 狀態與權限請求。
- 前景服務通知，避免啟動後立即被系統停止。

## 建置
需要 JDK 17、Android SDK 35、Android Gradle Plugin 8.7.3。
執行 `gradle assembleDebug`，APK 位於 `app/build/outputs/apk/debug/app-debug.apk`。

## 尚未完成
目前是第一個可建置骨架，不宣稱所有功能已完成。MediaSession 內容呈現、電量/網路即時狀態、完整動態島互動動畫、Shizuku UserService/特權操作與實機相容性測試仍需後續實作。
